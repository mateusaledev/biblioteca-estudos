package br.com.buzzi.campeonatobrasileiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivecodingCampeonatoBrasileiroApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivecodingCampeonatoBrasileiroApplication.class, args);
	}

}
