package br.com.buzzi.campeonatobrasileiro.dto;

import lombok.Data;

@Data
public class AtualizarJogoDTO {

}
