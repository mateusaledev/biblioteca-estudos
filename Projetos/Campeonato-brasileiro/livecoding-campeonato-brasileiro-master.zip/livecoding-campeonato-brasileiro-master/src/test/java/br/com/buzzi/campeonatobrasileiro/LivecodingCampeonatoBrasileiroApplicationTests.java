package br.com.buzzi.campeonatobrasileiro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivecodingCampeonatoBrasileiroApplicationTests {

	@Test
	void contextLoads() {
	}

}
